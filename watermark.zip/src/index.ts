export { default as Foo } from './watermark';
