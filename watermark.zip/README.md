# watermark

[![NPM version](https://img.shields.io/npm/v/watermark.svg?style=flat)](https://npmjs.org/package/watermark)
[![NPM downloads](http://img.shields.io/npm/dm/watermark.svg?style=flat)](https://npmjs.org/package/watermark)

watermark

## Usage

TODO

## Options

TODO

## Development

```bash
# install dependencies
$ pnpm install

# develop library by docs demo
$ pnpm start

# build library source code
$ pnpm run build

# build library source code in watch mode
$ pnpm run build:watch

# build docs
$ pnpm run docs:build

# check your project for potential problems
$ pnpm run doctor
```

## LICENSE

MIT
